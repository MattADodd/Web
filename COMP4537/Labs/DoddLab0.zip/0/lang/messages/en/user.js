const winMessage = "Excellent memory!";
const loseMessage = "Wrong order!";